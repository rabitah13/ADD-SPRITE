import pygame

pygame.init()

screen = pygame.display.set_mode((800, 600))

pygame.display.set_caption("Rectangle sprite game")

WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

player = pygame.Rect(100, 100, 50, 50)

enemy = pygame.Rect(400, 300, 60, 60)

speed = 5

clock = pygame.time.clock()

while True:
  for event in pygame.event.get():
    
    if event.type == pygame.QUIT:
      
      pygame.quit()
      
  keys =
pygame.key.get_pressed()  
  if keys[pygame.k_LEFT]:
    player.x -= speed
  if keys[pygame.k_RIGHT]:
    player.x +=speed
  if keys[pygame.k_UP]:
    player.y +=speed
  if keys[pygame.k_DOWN]:
    player.y -=speed
    
  screen.fill(WHITE)
  
  pygame.draw.rect(screen, BLUE, player)
  pygame.draw.rect(screen, RED, enemy)
  pygame.display.flip()
  clock.tick(60)
  
  
  
  
    
    
    
      
      
    